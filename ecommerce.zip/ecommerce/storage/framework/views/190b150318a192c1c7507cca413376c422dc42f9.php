 <div class="sidebar">
     <ul>


         <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><a href="<?php echo e($menu['url']); ?>"><?php echo e($menu['title']); ?></a>
             </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
 </div>
<?php /**PATH I:\multi vendor ecommerce\laravelecommerce\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>